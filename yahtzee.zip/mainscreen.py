from tkinter import *
from yahtzee import *
from menu import *
from rootmain import root

def update_root_title(title):
    root.title(title)

# Get the dimensions of the screen
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Set the window geometry to fill the entire screen
root.geometry(f"{screen_width}x{screen_height}+0+0")

# Load background image
bg_img = PhotoImage(file="Yahtzee.png")
bg_label = Label(root, image=bg_img)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Define the paths to the images for buttons
play_img_path = "play.png"
exit_img_path = "exit.png"
help_img_path = "help.png"

# Create image objects for each button
play_img = PhotoImage(file=play_img_path)
exit_img = PhotoImage(file=exit_img_path)
help_img = PhotoImage(file=help_img_path)

# Define functions to be called when buttons are clicked
def play_game():
    play_yahtzee()

def show_instructions():
    menu()

def exit_program():
    root.destroy()

# Create button widgets with the images as backgrounds
play_button = Button(root, image=play_img, bd=0, highlightthickness=0, command=play_game)
help_button = Button(root, image=help_img, bd=0, highlightthickness=0, command=show_instructions)
exit_button = Button(root, image=exit_img, bd=0, highlightthickness=0, command=exit_program)

# Place the buttons on the screen using absolute positioning
play_button.place(x=480, y=660)
help_button.place(x=620, y=660)
exit_button.place(x=770, y=660)

# Start the Tkinter main event loop
root.mainloop()
