import tkinter as tk
from rootmain import root

def update_root_title(title):
    root.title(title)

def menu():
    def display_instructions():
        instructions = "\nRULES OF YAHTZE GAME\n\n"
        instructions += " \nYahtzee is a dice game based on Poker\n.\n The object of the game is to roll certain combinations of numbers with five dice.\n"
        instructions += " \nYou will have 13 turns and in each turn you will have 3 chances to roll the dice\n"
        instructions += " \nYou need to save the dices in between the rolls in gaining good combinations\n"
        instructions += " \nYou will have 13 columns which helps to score in different ways\n"
        instructions += " \nAt the end ,after completing the three rolls , the score will be given as follows based on the selected dice :\n"
        instructions += " \nones : Itsums up the total no.of ones and add to the score\n"
        instructions += " \nTwos : It sums up the total no.of twos and add to the score\n"
        instructions += " \nSimilarly for 3,4,5,6 numbers it sums up and add to the score\n"
        instructions += " \n3 of a kind : Atleast if three of the dice are same,score for this is sum of all dice\n"
        instructions += " \n4 of a kind : Atleast if four of the dice are same,score for this is sum of all dice.\n"
        instructions += " \nFULL HOUSE : Three of a kind and a pair ,Score : 25 points.\n"
        instructions += " \nSmall Straight : Three dice in a sequence, Score : 30 points.\n"
        instructions += " \nLarge Straight : Four dice in a sequence, Score : 40 points..\n"
        instructions += " \nYahtzee : All the Dice have same number ,Score : 50 points\n"
        instructions += " \nChance : All the Dice have different numbers ,Score : sum of numbers on dice\n"
        instructions += " \nBonus : if the sum of scores from 1's to 6's is > 63 ; bonus score of 35 points is added\n"
        instructions += " \nNOTE : You need to select wisely to score more, if not you will get a chance to opt for zero marks, as it is must to select boxes after 3 rolls\n"
        instruction_label.config(text=instructions)

    # create the instructions window
    instructions_window = tk.Toplevel(root)
    instructions_window.geometry("1530x910")
    instructions_window.configure(bg='#FFE4C4')

    # create a label to display the instructions
    instruction_label = tk.Label(instructions_window, text="", bg='#FFE4C4', fg='#000000')
    instruction_label.pack()

    # display the instructions
    display_instructions()

    # start the main event loop for the instructions window
    instructions_window.mainloop()


